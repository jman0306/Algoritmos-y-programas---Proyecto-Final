/*
 * Juan Manuel Ambriz Nu�ez  195554
 * 25/11/2020
 * Clase para trabajar con el estacionamiento a traves de una ventana 
 */
public class EVistaFiesta {

	public static void main(String[] args) {
		//VistaEstacionamiento miVentana;
		ControladorVistaFiesta miVentana;
		
		miVentana= new ControladorVistaFiesta();
		miVentana.pack();
		miVentana.setVisible(true);
		

	}

}